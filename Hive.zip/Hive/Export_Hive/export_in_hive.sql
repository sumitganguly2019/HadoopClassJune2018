from departments dept
insert overwrite table dept_export
select dept.*
insert overwrite local directory '/tmp/dept_records'
select dept.*
insert overwrite directory '/user/cloudera/dept_export'
select dept.*;
